public class Const {
    public static final int WIDTH = 600;
    public static final int HEIGHT = 500;
    public static final int SCORE_WIDTH = 120;
    public static final int PAD_STEP = 20;
    public static final long PRIZE_TIME = 8192L;
    public static final long UPDATE_TIME = 4096L;
    public static final long BLINKING_TIME = 2048L;
    public static final int PAD_WIDTH = 120;
    public static final int PAD_HEIGHT = 20;
}
