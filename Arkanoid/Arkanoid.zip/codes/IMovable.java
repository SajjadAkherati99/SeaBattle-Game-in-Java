public interface IMovable extends IPaintable {
    public void move();
}
