import java.awt.event.KeyListener;

public interface Listener extends IPaintable, KeyListener {
}
